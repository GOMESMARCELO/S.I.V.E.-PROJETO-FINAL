-- Modelo físico do S.I.V.E.: somente a estrutura (CREATE TABLE), sem dados de demonstração.
-- Banco de dados do S.I.V.E. (MySQL)
SET NAMES utf8mb4;
DROP DATABASE IF EXISTS sive;
CREATE DATABASE sive CHARACTER SET utf8mb4;
USE sive;

CREATE TABLE alunos (
  id INT AUTO_INCREMENT PRIMARY KEY,
  nome VARCHAR(100) NOT NULL,
  sala VARCHAR(20) NOT NULL,
  matricula VARCHAR(20) UNIQUE
);
CREATE TABLE responsaveis (
  id INT AUTO_INCREMENT PRIMARY KEY,
  nome VARCHAR(100) NOT NULL,
  telefone VARCHAR(20),
  foto VARCHAR(200)
);
CREATE TABLE aluno_responsavel (
  aluno_id INT, responsavel_id INT, parentesco VARCHAR(20),
  PRIMARY KEY (aluno_id, responsavel_id),
  FOREIGN KEY (aluno_id) REFERENCES alunos(id),
  FOREIGN KEY (responsavel_id) REFERENCES responsaveis(id)
);
CREATE TABLE acessos (
  id INT AUTO_INCREMENT PRIMARY KEY,
  aluno_id INT, sala VARCHAR(20), data_hora DATETIME DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (aluno_id) REFERENCES alunos(id)
);
CREATE TABLE saidas (
  id INT AUTO_INCREMENT PRIMARY KEY,
  aluno_id INT, data_hora DATETIME DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (aluno_id) REFERENCES alunos(id)
);
-- Autorização digital: uma linha por aluno. "grupo" liga as linhas criadas juntas (ex.: passeio da turma toda).
-- Ao assinar, o sistema grava quem assinou, o nome digitado, quando e um código de verificação.
CREATE TABLE autorizacoes (
  id INT AUTO_INCREMENT PRIMARY KEY,
  grupo VARCHAR(20) NOT NULL,
  aluno_id INT NOT NULL,
  titulo VARCHAR(100) NOT NULL,
  validade VARCHAR(50),
  detalhe VARCHAR(250),
  criada_em DATETIME DEFAULT CURRENT_TIMESTAMP,
  criada_por_nome VARCHAR(100),
  assinada BOOLEAN NOT NULL DEFAULT FALSE,
  assinada_por INT NULL,
  assinada_nome VARCHAR(100) NULL,
  assinada_em DATETIME NULL,
  codigo VARCHAR(20) NULL,
  FOREIGN KEY (aluno_id) REFERENCES alunos(id)
);
-- Uma linha por aluno por dia (a chamada do professor grava aqui)
CREATE TABLE presencas (
  id INT AUTO_INCREMENT PRIMARY KEY,
  aluno_id INT NOT NULL, data DATE NOT NULL, status ENUM('Presente','Ausente') NOT NULL, observacao VARCHAR(100),
  UNIQUE KEY uq_presenca_aluno_dia (aluno_id, data),
  FOREIGN KEY (aluno_id) REFERENCES alunos(id)
);

-- Busca Ativa: casos abertos automaticamente quando o aluno acumula muitas faltas
CREATE TABLE busca_ativa (
  id INT AUTO_INCREMENT PRIMARY KEY,
  aluno_id INT NOT NULL,
  faltas_ao_abrir INT NOT NULL,
  status ENUM('Em acompanhamento','Resolvido') NOT NULL DEFAULT 'Em acompanhamento',
  aberta_em DATETIME DEFAULT CURRENT_TIMESTAMP,
  encerrada_em DATETIME NULL,
  FOREIGN KEY (aluno_id) REFERENCES alunos(id)
);
-- Anotações de acompanhamento de cada caso (quem anotou, quando e o quê)
CREATE TABLE busca_ativa_registros (
  id INT AUTO_INCREMENT PRIMARY KEY,
  busca_id INT NOT NULL,
  usuario_id INT NULL,
  nome_usuario VARCHAR(100) NOT NULL,
  texto VARCHAR(500) NOT NULL,
  data_hora DATETIME DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (busca_id) REFERENCES busca_ativa(id)
);

-- papel: 'admin' (gestão), 'pai' (responsável) ou 'professor'
-- sala: só é usada por professores, indica a turma que ele leciona
-- senha_temporaria: true quando a senha foi gerada pelo administrador e ainda não foi trocada
-- ultimo_acesso: usado pelo sistema de reativação (60 dias sem acessar)
CREATE TABLE usuarios (
  id INT AUTO_INCREMENT PRIMARY KEY,
  usuario VARCHAR(50) UNIQUE NOT NULL,
  senha VARCHAR(100) NOT NULL,
  papel ENUM('admin','pai','professor') NOT NULL,
  nome VARCHAR(100) NOT NULL,
  aluno_id INT NULL,
  sala VARCHAR(20) NULL,
  senha_temporaria BOOLEAN NOT NULL DEFAULT FALSE,
  ativo BOOLEAN NOT NULL DEFAULT TRUE,
  ultimo_acesso DATETIME NULL,
  criado_em DATETIME DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (aluno_id) REFERENCES alunos(id)
);

-- Registro de quem fez o quê no sistema (logs de atividade)
CREATE TABLE logs (
  id INT AUTO_INCREMENT PRIMARY KEY,
  usuario_id INT NULL,
  nome_usuario VARCHAR(100) NOT NULL,
  papel VARCHAR(20) NOT NULL,
  acao VARCHAR(60) NOT NULL,
  detalhe VARCHAR(255),
  data_hora DATETIME DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (usuario_id) REFERENCES usuarios(id)
);

-- Comunicados: sala vazia = vai para a escola toda
CREATE TABLE comunicados (
  id INT AUTO_INCREMENT PRIMARY KEY,
  titulo VARCHAR(120) NOT NULL,
  texto VARCHAR(1500) NOT NULL,
  sala VARCHAR(20) NULL,
  criado_por_nome VARCHAR(100) NOT NULL,
  criado_em DATETIME DEFAULT CURRENT_TIMESTAMP
);
-- Quem leu: um registro por comunicado e por aluno (o responsável marca como lido)
CREATE TABLE comunicado_leituras (
  comunicado_id INT NOT NULL,
  aluno_id INT NOT NULL,
  usuario_id INT NULL,
  lido_em DATETIME DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (comunicado_id, aluno_id),
  FOREIGN KEY (comunicado_id) REFERENCES comunicados(id),
  FOREIGN KEY (aluno_id) REFERENCES alunos(id)
);
-- Documentos anexados à ficha do aluno (o arquivo fica na pasta uploads/, com nome aleatório)
CREATE TABLE documentos (
  id INT AUTO_INCREMENT PRIMARY KEY,
  aluno_id INT NOT NULL,
  categoria VARCHAR(30) NOT NULL,
  titulo VARCHAR(120) NOT NULL,
  nome_original VARCHAR(200) NOT NULL,
  arquivo VARCHAR(80) NOT NULL,
  tipo_mime VARCHAR(100) NOT NULL,
  tamanho INT NOT NULL,
  enviado_por_nome VARCHAR(100) NOT NULL,
  enviado_em DATETIME DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (aluno_id) REFERENCES alunos(id)
);
-- Pendências abertas pela escola (ex.: entregar um documento)
CREATE TABLE pendencias (
  id INT AUTO_INCREMENT PRIMARY KEY,
  aluno_id INT NOT NULL,
  tipo ENUM('Documento','Cadastro','Outro') NOT NULL,
  descricao VARCHAR(200) NOT NULL,
  status ENUM('Aberta','Resolvida') NOT NULL DEFAULT 'Aberta',
  criada_em DATETIME DEFAULT CURRENT_TIMESTAMP,
  criada_por_nome VARCHAR(100) NOT NULL,
  resolvida_em DATETIME NULL,
  resolvida_por_nome VARCHAR(100) NULL,
  FOREIGN KEY (aluno_id) REFERENCES alunos(id)
);
-- Ações e advertências registradas sobre o aluno
CREATE TABLE ocorrencias (
  id INT AUTO_INCREMENT PRIMARY KEY,
  aluno_id INT NOT NULL,
  tipo ENUM('Advertencia','Acao') NOT NULL,
  descricao VARCHAR(500) NOT NULL,
  data_ocorrencia DATE NOT NULL,
  registrada_por_nome VARCHAR(100) NOT NULL,
  criada_em DATETIME DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (aluno_id) REFERENCES alunos(id)
);
